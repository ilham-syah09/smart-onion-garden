<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_data extends CI_Model {

	public function getData()
    {
        $this->db->order_by('waktu', 'desc');
        return $this->db->get('tb_bawang')->result_array();

    }

    public function delete($id)
    {
        // $this->db->where('id', $id);
        $this->db->delete('tb_bawang', ['id' => $id]);
    }

    public function save($value_ph)
    {
        $data = [
            "value_ph"   => $value_ph,
        ];

        $insert = $this->db->insert('tb_bawang', $data);
    }
        

}

/* End of file M_data.php */
/* Location: ./application/models/M_data.php */