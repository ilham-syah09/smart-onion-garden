<div class="content">
	<div class="row">
        <div class="col-lg-3">
          <div class="card" style="width: 16rem;">      
              <div class="card-body">
                <h5>Jumlah Data</h3>
                <h1><?= $count_data; ?></h1>
                <a href="<?= base_url('dashboard/data');?>" class="btn btn-sm btn-success">Detail</a>
              </div>
            </div>
        </div>
      </div>
    </div>
</div>
<script>
    function tampil(){
    $.ajax({
        url: "<?= base_url('Dashboard/realtime')?>",
        dataType: 'json',
        success:function(result){
          
          $('#value').text(result.jumlah);
          
          setTimeout(tampil, 2000); 
        }
    });
  }
  
  document.addEventListener('DOMContentLoaded',function(){
    tampil();
  });   
</script>