<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Data extends CI_Controller {

	public function save()
	{
		$this->load->model('M_data','data');
		$value_ph = $this->input->get('value_ph');
		$this->data->save($value_ph);
		echo 'sukses insert data';
	}

}

/* End of file Data.php */
/* Location: ./application/controllers/Data.php */